let userName = prompt("Пожалуйста, введите ваше имя:");

alert("Привет, " + userName + "!");